from django.urls import path
from . import views




urlpatterns = [
    path('' , views.dash),
    path('create/', views.eventCreate),
    path('<int:ev>/' , views.QuestionView),
    path('myevent/', views.myevent),
    path('ques/' , views.allques),
]

