from django.db import models


class Event(models.Model):
    Paid = 'مدفوع'
    Free = 'مجاني'

    CHOICES = (
    ('مدفوع', 'Paid'),
    ('مجاني', 'Free'),
)
    Name = models.CharField(max_length=30)
    Image = models.ImageField(upload_to='uploads/' )
    Brief = models.TextField(max_length=500)
    Location = models.CharField(max_length=128)
    Ticket = models.CharField(max_length=10 , choices=CHOICES , default =Paid)
    def __str__(self):
     return self.Name





class Q(models.Model):
    first = '1'
    second = '2'
    third = '3'
    fourth = '4'

    what = (
    ('1', 'first'),
    ('2', 'second'),
    ('3', 'third'),
    ('4', 'fourth'),
)
    Question = models.CharField(max_length=30)
    Answer = models.CharField(max_length=1 , choices=what , default = first )

    def __str__(self):
     return self.Question



class Question(models.Model):
    ques = models.CharField(max_length=255)
    ans1 = models.CharField(max_length=255)
    ans2 = models.CharField(max_length=255)
    ans3 = models.CharField(max_length=255)
    ans4 = models.CharField(max_length=255)

    def __str__(self):
     return self.ques


