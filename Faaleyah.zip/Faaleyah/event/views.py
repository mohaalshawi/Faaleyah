from django.shortcuts import render , redirect
from . import forms
from . import models

# Create your views here.

def eventCreate(request):
    if request.method == 'POST':
        form = forms.EventForm(request.POST , request.FILES)
        if form.is_valid():
                form.save()
        return redirect('../')
    else:
        form = forms.EventForm()
    return render(request, 'CreateEvent.html', {'form': form})


def eachevent(request , ev ):
    eventnum = models.Event.objects.get(id=ev)
    args = {'event' : eventnum }
    return render(request , 'each.html' , args )

def QuestionView(request , ev):
    if request.method == 'POST':
        form = forms.QuestionForm(request.POST)
        if form.is_valid():
                form.save()
        return redirect('../')
    else:
        form = forms.QuestionForm()
    return render(request, 'each.html', {'form': form})


def myevent(request):
    events = models.Event.objects.all()
    args = {'event' : events }
    return render(request , 'myevents.html' , args)

def dash(request):
    return render(request , 'dash.html')


def allques(request):
    questions = models.Question.objects.all()
    args = {'questions' : questions }
    return render(request , 'question.html' , args)

