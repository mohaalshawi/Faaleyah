from django import forms
from django.forms import ModelForm
from . import models

class EventForm(ModelForm):
    class Meta:
        model = models.Event
        fields = ['Name', 'Image' ,'Brief', 'Location', 'Ticket']



class QuestionForm(ModelForm):
    class Meta:
        model = models.Question
        fields = ['ques' , 'ans1', 'ans2', 'ans3', 'ans4' ]