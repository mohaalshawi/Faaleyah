from django.contrib import admin
from .models import Event , Question


class QAdmin(admin.ModelAdmin):
    list_display = ('id' , 'ques' ,'ans1','ans2','ans3','ans4')

class EventAdmin(admin.ModelAdmin):
    list_display = ('id' , 'Name' ,  'Ticket' , 'Location' )


admin.site.register(Event , EventAdmin)
admin.site.register(Question , QAdmin)